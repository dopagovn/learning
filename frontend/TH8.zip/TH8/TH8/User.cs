﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TH8
{
    public class User
    { 
        private string userName;
        private string password;
        private string firstName;
        private string lastName;
        private string email;
        private bool gender;
        private string address;

        public User() { }
        public User(string userName, string password, string firstName, string lastName, string email, bool gender, string address)
        {
            this.userName = userName;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.gender = gender;
            this.address = address;
        }

        public string UserName { get => userName; set => userName = value; }
        public string Password { get => password; set => password = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Email { get => email; set => email = value; }
        public bool Gender { get => gender; set => gender = value; }
        public string Address { get => address; set => address = value; }
    }
}