﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TH8
{
    public partial class QuanLyTaiKhoan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LayDuLieuVaoGridView();
            }
        }

        public void ThongBao(string a)
        {
            lblThongBao.Text = string.Format("{0}", a);
        }
        public void ThongBao(string a, string b)
        {
            lblThongBao.Text = string.Format("{0} {1}", a, b);
        }

        private void LayDuLieuVaoGridView()
        {
            UserDAO userDAO = new UserDAO();
            GridView1.DataSource = userDAO.GetAllUsers();
            GridView1.DataBind();
        }

        private void DoDuLieuLenForm(User user)
        {
            txtFirstName.Text = user.FirstName;
            txtLastName.Text = user.LastName;
            txtUserName.Text = user.UserName;
            txtPassword.Text = user.Password;
            txtDiaChi.Text = user.Address;
            txtEmail.Text = user.Email;
            rblGender.SelectedIndex = user.Gender ? 0 : 1;

        }
        public User LayDuLieuTuForm()
        {
            bool gender;
            if (rblGender.SelectedValue == "Nam")
            {
                gender = true;
            }
            else
            {
                gender = false;
            }
            
            User user = new User
            {
                UserName = txtUserName.Text,
                Password = txtPassword.Text,
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                Email = txtEmail.Text,
                Gender = gender,
                Address = txtDiaChi.Text
            };
            return user;
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string username = GridView1.SelectedRow.Cells[0].Text;

            UserDAO userDAO = new UserDAO();
            User user = userDAO.GetUserByUserName(username);
            if (user !=null)
            {
                //Đổ dữ liệu từ đối tượng User vào các trường trên Form
                DoDuLieuLenForm(user);
            }
        }

        protected void btnLoc_Click(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            //Lấy các dữ liệu từ giao diện
            User user = LayDuLieuTuForm();
            UserDAO userDAO = new UserDAO();
            //Kiểm tra user có tồn tại trong csdl chưa
            bool exist = userDAO.CheckUser(user.UserName);
            if (exist)
            {
                ThongBao("Username đã tồn tại");
            }
            else
            {
                bool result = userDAO.Insert(user);
                if (result)
                {
                    ThongBao("Đã đăng ký thành công", txtUserName.Text);
                }
                else
                {
                    ThongBao("Có lỗi vui lòng thử lại!");
                }

            }
            LayDuLieuVaoGridView();
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            string username = txtUserName.Text;
            User user = LayDuLieuTuForm();
            UserDAO userDAO = new UserDAO();

            bool exist = userDAO.CheckUser(txtUserName.Text);

            if (exist)
            {
                bool result = userDAO.DeleteUser(txtUserName.Text);
                if (result)
                {
                    ThongBao("Đã xoá thành công", txtUserName.Text);
                }
                else
                {
                    ThongBao("Có lỗi vui lòng thử lại");
                }
            }
            else
            {
                ThongBao("Không tồn tại Username", txtUserName.Text);
            }
            LayDuLieuVaoGridView();
        }

        protected void btnSua_Click(object sender, EventArgs e)
        {
            User user = LayDuLieuTuForm();
            UserDAO userDAO = new UserDAO();

            bool result = userDAO.UpdateUser(user);

            if (result)
            {
                ThongBao("Đã cập nhật thành công người dùng " + txtUserName.Text);
                LayDuLieuVaoGridView();
            }
            else
            {
                ThongBao("Cập nhật không thành công vui lòng thử lại!");
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtUserName.Text = "";
            txtPassword.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtEmail.Text = "";
            txtDiaChi.Text = "";
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            //Lấy username để xoá
            string username = GridView1.Rows[e.RowIndex].Cells[0].Text;

            UserDAO userDAO = new UserDAO();

            bool result = userDAO.DeleteUser(username);

            if (result)
            {
                ThongBao("Đã xoá thành công người dùng " + username);
                LayDuLieuVaoGridView();
            }
            else
            {
                ThongBao("Xoá không thành công vui lòng kiểm tra lại!");
            }
        }

        protected void btnDelete2_Click(object sender, EventArgs e)
        {
            string username = "";

            UserDAO userDAO = new UserDAO();

            bool result = userDAO.DeleteUser(username);

            if (result)
            {
                ThongBao("Đã xoá thành công người dùng " + username);
                LayDuLieuVaoGridView();
            }
            else
            {
                ThongBao("Xoá không thành công vui lòng kiểm tra lại!");
            }
        }
    }
}