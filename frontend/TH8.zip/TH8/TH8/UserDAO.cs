﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace TH8
{
    public class UserDAO
    {
        string connectionString = ConfigurationManager.ConnectionStrings["MyShop8ConnectionString"].ConnectionString;

        public DataTable GetAllUsers()
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"Select * from UserInfo";
                SqlCommand cmd = new SqlCommand(sql, connection);
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                return dataTable;
            }

        }
        public bool CheckUser(string userName)
        {
            string sql = @"SELECT COUNT(*) FROM UserInfo WHERE UserName=@usn";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@usn", userName);
                connection.Open();
                int count = (int)command.ExecuteScalar();
                return (count >= 1);
            }
        }

        public User GetUserByUserName(string username)
        {
            using(SqlConnection connection=new SqlConnection(connectionString))
            {
                string sql = @"SELECT * FROM UserInfo WHERE UserName=@usn";
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@usn", username);

                connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    User user = new User
                    {
                        UserName = (string)reader["UserName"],
                        Password = (string)reader["Password"],
                        FirstName = (string)reader["FirstName"],//Lấy giá trị theo từng cột trong CSDL
                        LastName = (string)reader["LastName"],
                        Email = (string)reader["Email"],
                        Gender = (Boolean)reader["Gender"],
                        Address = (string)reader["Address"] 
                    };
                    return user;
                }
            }
            return null;
        }

        public bool Insert(User user)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"INSERT INTO UserInfo(UserName, Password, FirstName, LastName, Email, Gender, Address) VALUES(@username, @password, @firstname, @lastname, @email, @gender, @address)";
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@username", user.UserName);
                cmd.Parameters.AddWithValue("@password", user.Password);
                cmd.Parameters.AddWithValue("@firstname", user.FirstName);
                cmd.Parameters.AddWithValue("@lastname", user.LastName);
                cmd.Parameters.AddWithValue("@email", user.Email);
                cmd.Parameters.AddWithValue("@gender", user.Gender);
                cmd.Parameters.AddWithValue("@address", user.Address);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                return (result >= 1);
            }

        }
        public bool UpdateUser(User user)
        {
            using(SqlConnection connection=new SqlConnection(connectionString))
            {
                string sql = @"UPDATE UserInfo SET FirstName=@firstname, LastName=@lastname, Email=@email, Gender=@gender, Address=@address, Password=@password Where UserName=@username";
                SqlCommand command = new SqlCommand(sql, connection);

                command.Parameters.AddWithValue("username", user.UserName);
                command.Parameters.AddWithValue("@password", user.Password);
                command.Parameters.AddWithValue("@firstname", user.FirstName);
                command.Parameters.AddWithValue("@lastname", user.LastName);
                command.Parameters.AddWithValue("@email", user.Email);
                command.Parameters.AddWithValue("@gender", user.Gender);
                command.Parameters.AddWithValue("@address", user.Address);

                connection.Open();
                int result = command.ExecuteNonQuery();
                if (result >= 1)
                {
                    return true;
                }          
            }
            return false;
        }
        public bool DeleteUser(string username)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"Delete from UserInfo where UserName=@user";

                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@user", username);
                connection.Open();

                int count =cmd.ExecuteNonQuery();
                if(count >= 1)
                {
                    return true;
                }
                return false;
            }
        }
    }
}